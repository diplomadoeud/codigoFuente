export const environment = {
  production: true,
  apiUrl: 'http://192.168.20.21:8280/'
};
