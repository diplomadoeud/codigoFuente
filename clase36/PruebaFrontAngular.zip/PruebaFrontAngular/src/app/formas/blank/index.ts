﻿export * from './blank.component';
