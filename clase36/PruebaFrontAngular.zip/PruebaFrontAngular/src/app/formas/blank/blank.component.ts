﻿import { Component, Injectable} from '@angular/core';


@Component({templateUrl: './blank.component.html'})

@Injectable()
export class BlankComponent  {


}

