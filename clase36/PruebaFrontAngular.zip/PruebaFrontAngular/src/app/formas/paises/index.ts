﻿export * from './paises.component';
