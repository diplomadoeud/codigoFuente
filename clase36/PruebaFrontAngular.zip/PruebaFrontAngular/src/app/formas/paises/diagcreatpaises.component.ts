import {Component, Inject, NgZone, OnInit, ViewChild} from '@angular/core';
import {MAT_DIALOG_DATA, MatDialogRef} from '@angular/material/dialog';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {PaisesService} from '../../services/paises.service';
import {PaisesInterface} from '../../interfaces/PaisesInterface';


@Component({
  selector: 'app-diagcreatdependencsp-component',
  templateUrl: 'diagcreatpaisescomponent.html'
})
export class DialogcreatpaisesComponent implements OnInit {
  paisesForm: FormGroup;
  dataAdded: Array<PaisesInterface>;

  constructor(
    public dialogRef: MatDialogRef<DialogcreatpaisesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private builder: FormBuilder,
    private msService: PaisesService,
    private ngZone: NgZone) {


  }

  public Close(resultad: boolean): void {
    let resultado: any;
    if (resultad === true) {
      resultado = {result: resultad, dataAdded: this.dataAdded};
    } else {
      resultado = {result: resultad, dataAdded: null};
    }
    this.dialogRef.close(resultado);
  }

  onSubmitCrear(): void {


  }


  iniciarForm(): void {

  }

  ngOnInit(): void {
    this.iniciarForm();
  }


}

