export class PaisesModel {
    public organizationId: number;
    public instrumento: number;
    public mincomfunc: number;
    public maxcomfunc: number;
    public valpcomfunc: number;
    public mincomcomp: number;
    public maxcomcomp: number;
    public valpcomcomp: number;
    public evalpareadep: number;
    public evalpotrosfac: number;
    public mincomfuncpp: number;
    public maxcomfuncpp: number;
    public valpcomfuncpp: number;
    public mincomcomppp: number;
    public maxcomcomppp: number;
    public valpcomcomppp: number;
    public evalpareadeppp: number;
    public evalpotrosfacpp: number;
    public tipoevalextraord: number;

    public mincomfuncpe: number;
    public maxcomfuncpe: number;
    public valpcomfuncpe: number;
    public mincomcomppe: number;
    public maxcomcomppe: number;
    public valpcomcomppe: number;
    public evalpareadeppe: number;
    public evalpotrosfacpe: number;

    public observaciones: string;

    constructor(json: any = null) {
        if (json !== null) {
            this.organizationId = json.organizationId;
            this.instrumento = json.instrumento;
            this.mincomfunc = json.mincomfunc;
            this.maxcomfunc = json.maxcomfunc;
            this.valpcomfunc = json.valpcomfunc;
            this.mincomcomp = json.mincomcomp;
            this.maxcomcomp = json.maxcomcomp;
            this.valpcomcomp = json.valpcomcomp;
            this.evalpareadep = json.evalpareadep;
            this.evalpotrosfac = json.evalpotrosfac;

            this.mincomfuncpp = json.mincomfuncpp;
            this.maxcomfuncpp = json.maxcomfuncpp;
            this.valpcomfuncpp = json.valpcomfuncpp;
            this.mincomcomppp = json.mincomcomppp;
            this.maxcomcomppp = json.maxcomcomppp;
            this.valpcomcomppp = json.valpcomcomppp;
            this.evalpareadeppp = json.evalpareadeppp;
            this.evalpotrosfacpp = json.evalpotrosfacpp;
            this.tipoevalextraord = json.tipoevalextraord;
            this.mincomfuncpe = json.mincomfuncpe;
            this.maxcomfuncpe = json.maxcomfuncpe;
            this.valpcomfuncpe = json.valpcomfuncpe;
            this.mincomcomppe = json.mincomcomppe;
            this.maxcomcomppe = json.maxcomcomppe;
            this.valpcomcomppe = json.valpcomcomppe;
            this.evalpareadeppe = json.evalpareadeppe;
            this.evalpotrosfacpe = json.evalpotrosfacpe;

            this.observaciones = json.observaciones;
        } else {
            this.organizationId = null;
            this.instrumento = null;
            this.mincomfunc = null;
            this.maxcomfunc = null;
            this.valpcomfunc = null;
            this.mincomcomp = null;
            this.maxcomcomp = null;
            this.valpcomcomp = null;
            this.evalpareadep = null;
            this.evalpotrosfac = null;
            this.mincomfuncpp = null;
            this.maxcomfuncpp = null;
            this.valpcomfuncpp = null;
            this.mincomcomppp = null;
            this.maxcomcomppp = null;
            this.valpcomcomppp = null;
            this.evalpareadeppp = null;
            this.evalpotrosfacpp = null;

            this.tipoevalextraord = null;
            this.mincomfuncpe = null;
            this.maxcomfuncpe = null;
            this.valpcomfuncpe = null;
            this.mincomcomppe = null;
            this.maxcomcomppe = null;
            this.valpcomcomppe = null;
            this.evalpareadeppe = null;
            this.evalpotrosfacpe = null;

            this.observaciones = null;
        }
    }
}
