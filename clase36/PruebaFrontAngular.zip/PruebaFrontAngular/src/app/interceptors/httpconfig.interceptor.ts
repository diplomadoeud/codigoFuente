import {Injectable} from '@angular/core';
import {
    HttpInterceptor,
    HttpRequest,
    HttpResponse,
    HttpHandler,
    HttpEvent,
    HttpErrorResponse
} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {map, catchError} from 'rxjs/operators';
import {AppCargandoService} from '../appBase/cargando/app.cargando.service';

@Injectable()
export class HttpConfigInterceptor implements HttpInterceptor {
    constructor(private cargandoService: AppCargandoService) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        request = request.clone({
            setHeaders: {
                Authorization: 'Bearer ' + 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJ1c2VyIiwiaWF0IjoxNjAxNzI3MTI2LCJleHAiOjE2MDE4NDcxMjZ9.c_KObkX9e9EGiGNlwd80mJawvlaOBbrSKj4sVYZi4nQoO3N0rkB3CGtWntPDdGHJgJy8jJAO7_T3xQzGTYrFBw'
            }
        });
        return next.handle(request).pipe(
            map((event: HttpEvent<any>) => {
                if (event instanceof HttpResponse) {
                }
                return event;
            }),
            catchError((error: HttpErrorResponse) => {
                if ((error.status === 401) || (error.status === 403)) {

                } else {
                }
                this.cargandoService.detenCargando();
                return throwError(error);
            }));
    }
}
