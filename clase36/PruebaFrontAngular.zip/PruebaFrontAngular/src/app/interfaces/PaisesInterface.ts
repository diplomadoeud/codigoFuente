export interface PaisesInterface {
  idPai: number;
  nombre: string;
  abreviatura: number;
}
